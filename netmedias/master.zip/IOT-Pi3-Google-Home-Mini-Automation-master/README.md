# IOT-Pi3-GoogleHome-Automation
IOT-Pi3-Alexa-Automation

YouTube Tutorial

https://www.youtube.com/watch?v=1Eo9NSiS3Y8

Downlod RASPBIAN STRETCH WITH DESKTOP

https://www.raspberrypi.org/downloads/raspbian/
